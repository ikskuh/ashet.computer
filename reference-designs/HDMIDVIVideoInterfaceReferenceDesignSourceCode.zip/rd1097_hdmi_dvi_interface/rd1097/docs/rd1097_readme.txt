          ********************************************************
          *                                                      *
          *  Lattice RD1097 - HDMI/DVI Multimedia Interface Demo *
          *                                                      *
          ********************************************************

==================================================================================================
Sub-directory and File List:

File List 

1.  rd1097_hdmi_dvi_interface\rd1097\docs\rd1097.pdf                                        									--> Functional descriptions of the HDMI/DVI Receiver and Transmitter modules
    rd1097_hdmi_dvi_interface\rd1097\docs\rd1097_readme.txt                                 									--> read me file (this file)
	rd1097_hdmi_dvi_interface\rd1097\docs\revision_history.xls																	--> Revision History
	rd1097_hdmi_dvi_interface\rd1097\docs\ug36.pdf																				--> HDMI/DVI Loopback demo using LatticeECP3 Video Protocol board
                                                                   
2.  rd1097_hdmi_dvi_interface\rd1097\project\<Device_name>\verilog\<Device_name>_verilog.ldf									--> Lattice Diamond Design files to open diamond project	
	rd1097_hdmi_dvi_interface\rd1097\project\<Device_name>\verilog\<Device_name>_verilog.lpf                               		--> Preference constraint file for Diamond
    rd1097_hdmi_dvi_interface\rd1097\project\<Device_name>\verilog\<Device_name>_verilog.sty                                	--> Lattice Diamond Startegy file
	rd1097_hdmi_dvi_interface\rd1097\project\ecp3\verilog\pcs_hdmi_10b.txt                                                      --> SERDES/PCS auto-configuration text file for ECP3 design
                                                                  

	                                                                 
3.  rd1097_hdmi_dvi_interface\rd1097\source\verilog\colorbar_music_bb.v                               							--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\ddc.v                        									 			--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\hdmi_audio_dec_bb.v                            								--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\hdmi_lnk_ctl.v                                  							--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\hdmi_receiver_bb.v                                							--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\hdmi_transmitter_bb.v                           							--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\i2s_enc.v                         											--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\ql_i2cs.v                                									--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\resync_pulse.v                          									--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\rlos_reset.v                             									--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\sci_config.v                                   								--> source code file - Verilog file
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\ecp3\ipexpress\                                 							--> source code file - IPexpress files
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\ecp3\ngo\                            										--> source code file - NGO files
    rd1097_hdmi_dvi_interface\rd1097\source\verilog\ecp3\hdmi_top.v                         									--> source code file - Verilog top file
                                                                    
         
        
---------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------
HOW TO OPEN A PROJECT IN DIAMOND:
---------------------------------------------------------------------------------------------------------------
1. Unzip the respective design files.
2. Launch Diamond and select "File -> Open -> Project..."
3. In the Open Project dialog, enter the Project location -- "\rd1008\project",select one device and then select one project.
4. Click Finish. Now the project is successfully loaded. 

---------------------------------------------------------------------------------------------------------------
HOW TO RUN PLACE AND ROUTE, JEDEC GENERATION, AND TIMING ANALYSIS IN DIAMOND:
---------------------------------------------------------------------------------------------------------------

1. Click the Process tab in the process panel of the Diamond dashboard. 
   Double click on Place and Route Design. This will bring the
   design through synthesis, mapping, and place and route.
2. Click the Process tab in the process panel of the Diamond dashboard.
   a) ECP3: Double click on "Export Files -> JEDEC File". This will generate
      the Jedec file for the design.
3. Once Place and Route is done, user can double click on Place and Route Trace
   Report on the right-side panel to get the timing analysis result.
4. Double click on "Export Files -> verilog Simulation File". This will generate
   the VO and SDF files for the timing simulation of the design.



